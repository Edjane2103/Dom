numero = int(input("Digite o seu número: "))
num = 0

while num <= numero:
    print (num)
    num = num + 1